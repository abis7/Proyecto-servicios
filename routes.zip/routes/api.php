<?php
use App\Http\Controllers\api\userController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

Route::get('/user', function (Request $request) {
    return $request->user();
})->middleware('auth:sanctum');


Route::post('hola', function(){
    return 'Hola Mundo';
});


Route::prefix('usuario')->group(function() {
    Route::get('', [userController::class, 'index']);
    Route::post('', [userController::class, 'create']);
    Route::get('/{id}', [userController::class, 'show'])->where('id', '[0-9]+');
    Route::patch('/{id}', [userController::class, 'update'])->where('id', '[0-9]+');
    Route::delete('/{id}', [userController::class, 'destroy'])->where('id', '[0-9]+');   
});
/*ID conssecutivo*/ 